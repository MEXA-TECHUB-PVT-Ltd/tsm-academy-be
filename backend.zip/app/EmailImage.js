const imageURL = 'https://res.cloudinary.com/dxfdrtxi3/image/upload/v1701854708/logom_ihpui6.png';

module.exports =  imageURL;
