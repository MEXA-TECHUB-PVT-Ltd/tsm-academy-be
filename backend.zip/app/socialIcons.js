// urls.js
const FacebookImageUrl='https://res.cloudinary.com/dxfdrtxi3/image/upload/v1698903493/facebook_icon_pbxcle.png'
const InstagramImageUrl='https://res.cloudinary.com/dxfdrtxi3/image/upload/v1698903650/instagram_icon_fe3vkq.png'
const TwitterImageUrl ='https://res.cloudinary.com/dxfdrtxi3/image/upload/v1698903760/twitter_icon_fd6jya.png'
const youtubeImageUrl='https://res.cloudinary.com/dxfdrtxi3/image/upload/v1698904087/likeinT_tozjew.png'

const facebookLink='https://www.facebook.com/MTechub-103194128852450'
const instagramLink='https://www.instagram.com/mtechub/'
const twitterLink='https://twitter.com/mtechub'
const youtubeLink='https://www.youtube.com/channel/UCZ3Z9Qq6Z3Z9Qq6Z3Z9Qq6w'
module.exports = {FacebookImageUrl,InstagramImageUrl,TwitterImageUrl,youtubeImageUrl,facebookLink,instagramLink,twitterLink,youtubeLink};