// urls.js
const admin_email="testing.mtechub@gmail.com"

module.exports = {admin_email};